package atividade1909;

import javax.swing.JFrame;

public class Atividade1909 {

    public static void main(String[] args) {
        Janela janela = new Janela();
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
	janela.setSize(450,250);
        janela.setLocationRelativeTo(null);
	janela.setVisible(true);
    }
    
}
